package adapter;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.app.MainActivity;
import com.example.app.R;


// adapter class fro custom menu list
public class AdapterMenuList extends BaseAdapter {

	private Activity activity;
//	public ImageLoader imageLoader;
	Context context;
	
	static ArrayList<String> temp1 = new ArrayList<String>();

	public AdapterMenuList(Activity act, Context context,
			ArrayList<String> temp1) {
		this.activity = act;
//		imageLoader = new ImageLoader(act);
		this.context = context;
		this.temp1 = temp1;
//		Log.v("Temp List in Adapter Constructer", temp+"");
	}

	public int getCount() {
		// TODO Auto-generated method stub
		return MainActivity.tempList.size();
	}

	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	ViewHolder holder;

	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub

		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) activity
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.menu_list_item, null);
			holder = new ViewHolder();
			convertView.setTag(holder);

		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		holder.txtdate = (TextView) convertView.findViewById(R.id.tvdate);
		holder.txtdate.setText(MainActivity.daysList.get(position));
		
		Log.v("Days -- ", MainActivity.daysList+"");
		Log.v("Temp -- ", MainActivity.tempList+"");
		Log.v("Pressure -- ", MainActivity.pressureList+"");
		Log.v("Humidity -- ", MainActivity.humidityList+"");
		Log.v("tempminList -- ", MainActivity.tempminList+"");
		Log.v("tempmaxList -- ", MainActivity.tempmaxList+"");
		Log.v("sealevelList -- ", MainActivity.sealevelList+"");
		Log.v("mainList -- ", MainActivity.mainList+"");
		Log.v("descList -- ", MainActivity.descList+"");
		
		Log.v("Temp LIST -- ", MainActivity.tempList.get(position));
				
		holder.temp = (TextView) convertView.findViewById(R.id.Temp);
		holder.temp.setText(MainActivity.tempList.get(position)+"K");

		holder.pressure = (TextView) convertView.findViewById(R.id.Pressure);
		holder.pressure.setText(MainActivity.pressureList.get(position));
		
		holder.humidity = (TextView) convertView.findViewById(R.id.Humidity);
		holder.humidity.setText(MainActivity.humidityList.get(position));
		
		holder.minTemp = (TextView) convertView.findViewById(R.id.TempMin);
		holder.minTemp.setText(MainActivity.tempminList.get(position)+"K");
		
		holder.maxTemp = (TextView) convertView.findViewById(R.id.TempMax);
		holder.maxTemp.setText(MainActivity.tempmaxList.get(position)+"K");
		
		holder.seaLevel = (TextView) convertView.findViewById(R.id.seaLevel);
		holder.seaLevel.setText(MainActivity.sealevelList.get(position));
		
		holder.main = (TextView) convertView.findViewById(R.id.main);
		holder.main.setText(MainActivity.mainList.get(position));
		
		holder.desc = (TextView) convertView.findViewById(R.id.desc);
		holder.desc.setText(MainActivity.descList.get(position));

		return convertView;
	}

	
	static class ViewHolder {
		TextView txtdate, temp, pressure, 
				humidity, minTemp, maxTemp, seaLevel,
				grndLevel, main, desc;
	}

}