package model;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

/**
 * Created by sneha on 18-02-2016.
 */
public class UserFunctions {

    public static String loadJson(String strUrl) {
        InputStream mInputStream = null;
        try {

            // This is the default apacheconnection.
            HttpClient mHttpClient = new DefaultHttpClient();

            // Path of serverside
            HttpPost mHttpPost = new HttpPost(strUrl);
            mHttpPost.setHeader("Accept", "application/json");
            mHttpPost.setHeader("Content-type", "application/json");
            mHttpPost.setHeader(HTTP.CONTENT_TYPE,
                    "application/x-www-form-urlencoded;charset=UTF-8");

          /*  if (alstNameValuePair != null) {
                // post the valur you want to pass.
                mHttpPost.setEntity(new UrlEncodedFormEntity(alstNameValuePair, "UTF-8"));
            }*/

            // get the valu from the saerverside as response.
            HttpResponse mHttpResponse = mHttpClient.execute(mHttpPost);
            HttpEntity mHttpEntity = mHttpResponse.getEntity();
            mInputStream = mHttpEntity.getContent();

        } catch (Exception e) {
            // TODO Auto-generated catch block
            // Log.e(strTAG,"Error in HttpClient,HttpPost,HttpResponse,HttpEntity");
            e.printStackTrace();
        }

        String strLine = null;
        String strResult = null;
        // convert response in to the string.
        try {
            BufferedReader mBufferedReader = new BufferedReader(
                    new InputStreamReader(mInputStream, "iso-8859-1"), 8);
            StringBuilder mStringBuilder = new StringBuilder();
            while ((strLine = mBufferedReader.readLine()) != null) {
                mStringBuilder.append(strLine + "\n");
            }
            mInputStream.close();
            strResult = mStringBuilder.toString();

        } catch (Exception e) {
            // Log.e(strTAG, "Error in BufferedReadering");
            e.printStackTrace();
        }
        return strResult;
    }

    public static boolean isConnectionAvailable(Context context) {

        ConnectivityManager connectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
            if (netInfo != null && netInfo.isConnected()
                    && netInfo.isConnectedOrConnecting()
                    && netInfo.isAvailable()) {
                return true;
            }
        }
        return false;
    }
//http://www.tutorialsbuzz.com/2015/02/android-expandable-listview-json-http.html

}