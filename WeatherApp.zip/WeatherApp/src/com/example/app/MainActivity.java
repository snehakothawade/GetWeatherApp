package com.example.app;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import model.ConnectionDetector;
import model.GPSTracker;
import model.UserFunctions;

import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import adapter.AdapterMenuList;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("NewApi")
public class MainActivity extends Activity {
	
	// flag for Internet connection status
    Boolean isInternetPresent = false;
     
    // Connection detector class
    ConnectionDetector cd;
    
 // GPSTracker class
    GPSTracker gps;
    
    Location mLastLocation;
    
    int flag=0;
    
    double latitude , longitude;
    List<Address> addresses;

	ProgressDialog progressDialog,progressDialog1;
	public ArrayList<NameValuePair> postParameters;
	
	Date date2;

	EditText cityId;
	Button getData;
	LinearLayout LayDetails;
	
	String geocityname;
	
	String main,desc,city_name;
	public String temp;
	String pressure;
	String humidity;
	String tempmin;
	String tempmax;
	String sealevel;
	String grndlevel;
	String cityname; 
	
	
	TextView tvCity,tvmain,tvdesc,tvTemp,tvMinTemp,tvMaxTemp,tvPressure,tvHumidity,tvseaLevel,tvdate;
	
	private InputStream isr;	
	private String result = "";
	String city_id;
	ArrayList<NameValuePair> nameValuePairs;
	
	long millislong;
    String millisstring;
    int millisec=0,sec=0,min=0,hour=0;
    
    public static  ArrayList<String> daysList = new ArrayList<String>();
    
    	
    public static String cityList = null;
    public static  ArrayList<String> mainList = new ArrayList<String>();
    public static  ArrayList<String> descList = new ArrayList<String>();
    public static  ArrayList<String> tempList = new ArrayList<String>();
    public static  ArrayList<String> pressureList = new ArrayList<String>();
    public static  ArrayList<String> humidityList = new ArrayList<String>();
    public static  ArrayList<String> tempminList = new ArrayList<String>();
    public static  ArrayList<String> tempmaxList = new ArrayList<String>();
    public static  ArrayList<String> sealevelList = new ArrayList<String>();
    public static  ArrayList<String> grndlevelList = new ArrayList<String>();
    
    public void clearData() {
		mainList.clear();
		descList.clear();
		tempList.clear();
		pressureList.clear();
		humidityList.clear();
		tempminList.clear();
		tempmaxList.clear();
		sealevelList.clear();
		grndlevelList.clear();
		daysList.clear();
	}
    
    ListView lv;
    AdapterMenuList menuAdapter,menuAdapterday;
    
    
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		 ActionBar actionBar = getActionBar();
		  actionBar.hide();


		cityId = (EditText) findViewById(R.id.etCityId);
		getData = (Button) findViewById(R.id.btnGet);
		
		lv = (ListView) findViewById(R.id.listView);
		
		tvCity = (TextView) findViewById(R.id.tvcity);

		
		// creating connection detector class instance
        cd = new ConnectionDetector(getApplicationContext());
        
        
        

		// create class object
        gps = new GPSTracker(MainActivity.this);

        // check if GPS enabled     
        if(gps.canGetLocation()){
             
             latitude = gps.getLatitude();
             longitude = gps.getLongitude();
             
             getAddress();
             
        }else{
            // can't get location
            // GPS or Network is not enabled
            // Ask user to enable GPS/network in settings
           gps.showSettingsAlert();
            
           
        }
     
		
		getData.setOnClickListener(new OnClickListener() {

			
			@Override
			public void onClick(View arg0) {
				// get Internet status
                isInternetPresent = cd.isConnectingToInternet();
 
				if(cityId.getText().toString().equals(""))

				{
					Toast.makeText(getApplicationContext(), "city name should not be blank.", Toast.LENGTH_LONG).show();
				}else
				
				
                // check for Internet status
                 if (isInternetPresent) {
                	
                	city_id = cityId.getText().toString();
    				
    				new LoadCityTask().execute();
                    
                } else {             	
                	Toast.makeText(getApplicationContext(), "You don't have internet connection.", Toast.LENGTH_LONG).show();
                }
			}
		});
		
		
       
             }  

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	class LoadCityTask extends AsyncTask<Void, Void, JSONObject> {
		@Override
        protected void onPreExecute() {
            super.onPreExecute();
		progressDialog = new ProgressDialog(MainActivity.this);
		progressDialog.setMessage("Loading Weather Details Please Wait");
		progressDialog.setCancelable(false);
		progressDialog.show();

		}

		@SuppressLint("SimpleDateFormat")
		@Override
		protected JSONObject doInBackground(Void... params) {
			
			String urlstr ="http://api.openweathermap.org/data/2.5/forecast/daily?q="+city_id+"&cnt=14&APPID=7e8fada346b20e737103b4cd58e32fde";

			String json = UserFunctions.loadJson(urlstr);
            
			clearData();
            
			try {
				JSONObject jsonRootObj = new JSONObject(json);
				JSONObject jsonObjCity = jsonRootObj.optJSONObject("city");
				city_name = jsonObjCity.getString("name").toString();
				
				Log.v("City Name -- ", city_name);
				
				cityList = city_name;
												
				JSONArray JsonArrayList = jsonRootObj.optJSONArray("list");
								
				for (int i = 0; i < JsonArrayList.length(); i++) {
					
					JSONObject jsonObjectgroup0 = JsonArrayList.getJSONObject(i);
					
					grndlevel= jsonObjectgroup0.getString("dt").toString();
					
					SimpleDateFormat dateFormat= new SimpleDateFormat("EEEE dd.MM.yyyy");
					Calendar currentCal = Calendar.getInstance();
					
					for(int p=0; p<15; p++)
					{
					currentCal.add(Calendar.DATE, -1); 
					String toDate=dateFormat.format(currentCal.getTime());
					
					daysList.add(toDate);
					}
					
					JSONObject jsonObjmain = jsonObjectgroup0.optJSONObject("temp");
					temp = jsonObjmain.getString("day").toString();
					pressure = jsonObjmain.getString("min").toString();
					humidity = jsonObjmain.getString("max").toString();
					tempmin = jsonObjmain.getString("night").toString();
					tempmax = jsonObjmain.getString("eve").toString();
					sealevel = jsonObjmain.getString("morn").toString();
					
										
					tempList.add(temp);
					pressureList.add(pressure);
					humidityList.add(humidity);
					tempminList.add(tempmin);
					tempmaxList.add(tempmax);
					sealevelList.add(sealevel);
					grndlevelList.add(grndlevel);
									
					
				JSONArray JsonArrayList2 = jsonObjectgroup0.getJSONArray("weather");
				for (int j = 0; j < JsonArrayList2.length(); j++) 
				{
				 JSONObject jsonObjectgroup1 = JsonArrayList2.getJSONObject(j);
				 main = jsonObjectgroup1.getString("main").toString();
				 desc = jsonObjectgroup1.getString("description").toString();
				
				System.out.print(main);
				System.out.print(desc);
				
				mainList.add(main);
				descList.add(desc);
				
				}
				}
				
              Log.v("Temp List -- ", tempList+"");
                              
    			
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
			return null;
		}

		@Override
		protected void onPostExecute(JSONObject result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if (progressDialog.isShowing()) {
				progressDialog.dismiss();
            }
			
			tvCity.setText(city_name);
			
			if(tempList.size() > 0){
            	menuAdapter = new AdapterMenuList(MainActivity.this,
            			getApplicationContext(), tempList);
            	lv.setAdapter(menuAdapter);
            	menuAdapter.notifyDataSetChanged();
            	Log.v("Temp List After Adapter Set -- ", tempList+"");            	          	
            	
            }
			
			if(daysList.size() > 0){
            	menuAdapterday = new AdapterMenuList(MainActivity.this,
            			getApplicationContext(), daysList);
            	lv.setAdapter(menuAdapterday);
            	menuAdapterday.notifyDataSetChanged();
            	Log.v("Temp List After Adapter Set -- ", daysList+"");            	          	
            	
            }

		}

	}
	
public void getAddress() {
    	
    	
    	new AsyncTask<String, String, String>() {

			@Override
			protected void onPreExecute() {
				super.onPreExecute();

				progressDialog1 = new ProgressDialog(MainActivity.this);
				progressDialog1.setMessage("Loading Current City Please Wait");
				progressDialog1.setCancelable(false);
				progressDialog1.show();
				
				geocityname = "";
		        
			}

			@Override
			protected String doInBackground(String... params) {

				 try {

			        	String jsonObj = UserFunctions.loadJson("http://maps.googleapis.com/maps/api/geocode/json?latlng=" + latitude + ","
			                    + longitude + "&sensor=true");
			        	JSONObject jsonRootObj = new JSONObject(jsonObj);
			        	
			            String Status = jsonRootObj.getString("status");
			            if (Status.equalsIgnoreCase("OK")) {
			                JSONArray Results = jsonRootObj.getJSONArray("results");
			                JSONObject zero = Results.getJSONObject(0);
			                JSONArray address_components = zero.getJSONArray("address_components");

			                for (int i = 0; i < address_components.length(); i++) {
			                    JSONObject zero2 = address_components.getJSONObject(i);
			                    String long_name = zero2.getString("long_name");
			                    JSONArray mtypes = zero2.getJSONArray("types");
			                    String Type = mtypes.getString(0);

			                    if (TextUtils.isEmpty(long_name) == false || !long_name.equals(null) || long_name.length() > 0 || long_name != "") {
			                         if (Type.equalsIgnoreCase("locality")) {
			                        	 geocityname = geocityname + long_name + ", ";
			                        	 geocityname = long_name;
			                        } 
			                    }
			                }
			            }

			        } catch (Exception e) {
			            e.printStackTrace();
			        }

				return null;
			}

			@Override
			protected void onPostExecute(String result) {
				// TODO Auto-generated method stub
				super.onPostExecute(result);
				
				if (progressDialog1.isShowing()) {
					progressDialog1.dismiss();
	            }
				
				cityId.setText(geocityname);
				
				//updateLocation();
			}

		}.execute();
		
    }



    
}


