package com.example.app;

public class ConstantsURL {
	
	// URLS
	
		public final static String GET_WEATHER = "http://api.openweathermap.org/data/2.5/forecast/city/";
		
}
